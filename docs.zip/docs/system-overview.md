# Documentación del proyecto MTS Platform

## 1. Visión general del proyecto

MTS Platform es una plataforma empresarial modular en desarrollo que incluye infraestructura, base de datos, backend Laravel y front-end React. El proyecto está organizado en sprints y en esta versión contiene:

- `docker-compose.yml`: Define los servicios de infraestructura.
- `database/`: Scripts SQL, migraciones y seeders para inicializar la base de datos.
- `backend/`: Aplicación Laravel con autenticación y contexto multi-tenant.
- `frontend/`: Espacio reservado para la interfaz de React.

El objetivo es construir un sistema multi-tenant donde cada empresa tenga datos aislados en la misma base PostgreSQL.

---

## 2. Arquitectura principal

### 2.1 Componentes

- PostgreSQL: Base de datos central.
- Redis: Caché y colas.
- pgAdmin: Administración de PostgreSQL.
- Mailpit: Captura correos de prueba.
- Laravel Backend: API REST y autenticación.
- Frontend React: consumo de la API (en desarrollo).

### 2.2 Flujo de despliegue

1. Copiar `.env.example` a `.env`.
2. Ajustar variables necesarias en `.env`.
3. Ejecutar `docker compose up -d`.
4. Inicializar la base de datos con los scripts SQL.

---

## 3. Servicios de Docker

El archivo `docker-compose.yml` define estos servicios:

- `postgres`:
  - Imagen: `postgres:16-alpine`
  - Usuario/contraseña desde `.env`
  - Volumen: `postgres_data`
  - Init scripts en `./docker/postgres/init`
- `redis`:
  - Imagen: `redis:7-alpine`
  - Volumen: `redis_data`
- `pgadmin`:
  - Imagen: `dpage/pgadmin4:8`
  - Configuración de servidor en `docker/pgadmin/servers.json`
  - Puerto `5050`
- `mailpit`:
  - Imagen: `axllent/mailpit:latest`
  - SMTP puerto `1025`, UI puerto `8025`

---

## 4. Modelo de datos principal

### 4.1 Tablas de referencia

- `countries`
- `currencies`
- `plans`
- `modules`

### 4.2 Tablas multi-tenant

- `companies`
- `subscriptions`
- `company_modules`

### 4.3 Tablas de usuarios y permisos

- `users`
- `company_user`
- `roles`
- `permissions`
- `role_has_permissions`
- `model_has_roles`
- `model_has_permissions`

### 4.4 Tablas de soporte

- `settings`
- `media`
- `audit_logs`
- `notifications`

---

## 5. Lógica multi-tenant y RLS

El sistema utiliza Row Level Security (RLS) para garantizar que las tablas con `company_id` solo muestren datos de la empresa actual. El role `mts_app` es el rol de aplicación recomendado para que RLS funcione correctamente.

### 5.1 Función de helper RLS

- Archivo: `docker/postgres/init/01-init.sql`
- Función: `current_company_id()`
- Uso: devuelve el valor de `app.current_company_id` en la sesión de PostgreSQL.

### 5.2 Políticas RLS clave

Las tablas con `company_id` activan `FORCE ROW LEVEL SECURITY` y usan políticas como:

```sql
CREATE POLICY tenant_isolation ON <tabla>
    USING (company_id = current_company_id());
```

---

## 6. Backend Laravel

### 6.1 Rutas principales

- `POST /api/register`
- `POST /api/login`
- `POST /api/logout`
- `GET /api/me`

### 6.2 Autenticación

El backend usa Sanctum para tokens API y Spatie Permission para roles/permissions.

### 6.3 Contexto de empresa

El middleware `EnsureCompanyContext` exige el header `X-Company-Id` y valida que el usuario pertenezca a la empresa antes de ejecutar la petición.

### 6.4 Controladores y modelos

- `App\Http\Controllers\Api\AuthController`
- `App\Http\Middleware\EnsureCompanyContext`
- `App\Models\User`
- `App\Models\Company`
- `App\Models\Role`
- `App\Models\Permission`

---

## 7. Cómo debe funcionar el sistema

1. Un usuario se registra con datos de empresa.
2. Se crea la empresa, se fija `app.current_company_id` y se clonan los roles base.
3. El usuario se crea y se agrega a `company_user` con `is_owner = true`.
4. Al iniciar sesión, el sistema devuelve las empresas a las que pertenece.
5. En llamadas autenticadas, el cliente debe enviar `X-Company-Id` para seleccionar la empresa activa.
6. El middleware valida la pertenencia y ajusta el contexto RLS.

---

## 8. Inicialización de la base de datos

El script `database/sql/run_all.ps1` ejecuta todos los archivos en orden y luego pide la contraseña para crear el rol `mts_app`.

### Archivos ejecutados

1. `001_reference_tables.sql`
2. `002_companies_and_tenancy.sql`
3. `003_users_roles_permissions.sql`
4. `004_support_tables.sql`
5. `005_rls_policies.sql`
6. `database/seeders/001_seed_core.sql`
7. `007_spatie_compatibility.sql`
8. `database/seeders/002_seed_demo_company.sql`
9. `008_get_user_companies.sql`

---

## 9. Estado actual y roadmap

- Sprint 0: infraestructura lista.
- Sprint 1: modelo de datos y políticas RLS.
- Sprint 2: backend Laravel básico.
- Sprint 3: frontend React en desarrollo.

---

## 10. Notas importantes

- `mts_user` es superusuario de PostgreSQL y no debe usarse en producción para la app.
- `mts_app` es el rol que se debe usar en Laravel para respetar RLS.
- El frontend aún no contiene código, solo `package-lock.json`.
